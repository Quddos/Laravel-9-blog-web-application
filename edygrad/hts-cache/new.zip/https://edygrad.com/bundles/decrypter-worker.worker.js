<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
<!-- CSRF Token -->
<meta name="csrf-token" content="aXa5IfOq9rYhvVexK4jw0FfbM2rVWEZEvxBH6z18">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<meta name='robots' content="NOODP, nofollow, noindex">


<link rel='shortcut icon' type='image/x-icon' href="https://edygrad.com/store/1/favicon2.png">
<link rel="manifest" href="/mix-manifest.json?v=4">
<meta name="theme-color" content="#FFF">
<!-- Windows Phone -->
<meta name="msapplication-starturl" content="/">
<meta name="msapplication-TileColor" content="#FFF">
<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
<!-- iOS Safari -->
<meta name="apple-mobile-web-app-title" content="EDYGRAD">
<link rel="apple-touch-icon" href="https://edygrad.com/store/1/favicon2.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<!-- Android -->
<link rel='icon' href='https://edygrad.com/store/1/favicon2.png'>
<meta name="application-name" content="EDYGRAD">
<meta name="mobile-web-app-capable" content="yes">
<!-- Other -->
<meta name="layoutmode" content="fitscreen/standard">
<link rel="home" href="https://edygrad.com">

<!-- Open Graph -->
<meta property='og:title' content=''>
<meta name='twitter:card' content='summary'>
<meta name='twitter:title' content=''>

<meta property='og:site_name' content='https://edygrad.com/EDYGRAD'>
<meta property='og:image' content='https://edygrad.com/store/1/favicon2.png'>
<meta name='twitter:image' content='https://edygrad.com/store/1/favicon2.png'>
<meta property='og:locale' content='https://edygrad.com/en_US'>
<meta property='og:type' content='website'>



    <title> | EDYGRAD</title>

    <!-- General CSS File -->
    <link rel="stylesheet" href="/assets/default/vendors/sweetalert2/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="/assets/default/vendors/toast/jquery.toast.min.css">
    <link rel="stylesheet" href="/assets/default/vendors/simplebar/simplebar.css">
    <link rel="stylesheet" href="/assets/default/css/app.css">

    
        
    <style>
        

        @font-face {
                      font-family: 'main-font-family';
                      font-style: normal;
                      font-weight: 400;
                      font-display: swap;
                      src: url(/store/1/fonts/montserrat-regular.woff2) format('woff2');
                    }@font-face {
                      font-family: 'main-font-family';
                      font-style: normal;
                      font-weight: bold;
                      font-display: swap;
                      src: url(/store/1/fonts/montserrat-bold.woff2) format('woff2');
                    }@font-face {
                      font-family: 'main-font-family';
                      font-style: normal;
                      font-weight: 500;
                      font-display: swap;
                      src: url(/store/1/fonts/montserrat-medium.woff2) format('woff2');
                    }@font-face {
                      font-family: 'rtl-font-family';
                      font-style: normal;
                      font-weight: 400;
                      font-display: swap;
                      src: url(/store/1/fonts/Vazir-Regular.woff2) format('woff2');
                    }@font-face {
                      font-family: 'rtl-font-family';
                      font-style: normal;
                      font-weight: bold;
                      font-display: swap;
                      src: url(/store/1/fonts/Vazir-Bold.woff2) format('woff2');
                    }@font-face {
                      font-family: 'rtl-font-family';
                      font-style: normal;
                      font-weight: 500;
                      font-display: swap;
                      src: url(/store/1/fonts/Vazir-Medium.woff2) format('woff2');
                    }

        :root{
--primary:#00539c;
--primary-border:#eea47f;
--primary-btn-shadow:box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset;;
--primary-btn-shadow-hover:box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset;;
--secondary-btn-shadow:box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset;;
--secondary-btn-shadow-hover:box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset;;
--secondary-btn-color-hover:#000000;
}

    </style>


            <style>
    .pace { -webkit-pointer-events: none; pointer-events: none; -webkit-user-select: none; -moz-user-select: none; user-select: none; } .pace-inactive { display: none; } .pace .pace-progress { background: #29d; position: fixed; z-index: 2000; top: 0; right: 100%; width: 100%; height: 2px; } .pace .pace-progress-inner { display: block; position: absolute; right: 0px; width: 100px; height: 100%; box-shadow: 0 0 10px #29d, 0 0 5px #29d; opacity: 1.0; -webkit-transform: rotate(3deg) translate(0px, -4px); -moz-transform: rotate(3deg) translate(0px, -4px); -ms-transform: rotate(3deg) translate(0px, -4px); -o-transform: rotate(3deg) translate(0px, -4px); transform: rotate(3deg) translate(0px, -4px); } .pace .pace-activity { display: block; position: fixed; z-index: 2000; top: 15px; right: 15px; width: 14px; height: 14px; border: solid 2px transparent; border-top-color: #29d; border-left-color: #29d; border-radius: 10px; -webkit-animation: pace-spinner 400ms linear infinite; -moz-animation: pace-spinner 400ms linear infinite; -ms-animation: pace-spinner 400ms linear infinite; -o-animation: pace-spinner 400ms linear infinite; animation: pace-spinner 400ms linear infinite; } @-webkit-keyframes pace-spinner { 0% { -webkit-transform: rotate(0deg); transform: rotate(0deg); } 100% { -webkit-transform: rotate(360deg); transform: rotate(360deg); } } @-moz-keyframes pace-spinner { 0% { -moz-transform: rotate(0deg); transform: rotate(0deg); } 100% { -moz-transform: rotate(360deg); transform: rotate(360deg); } } @-o-keyframes pace-spinner { 0% { -o-transform: rotate(0deg); transform: rotate(0deg); } 100% { -o-transform: rotate(360deg); transform: rotate(360deg); } } @-ms-keyframes pace-spinner { 0% { -ms-transform: rotate(0deg); transform: rotate(0deg); } 100% { -ms-transform: rotate(360deg); transform: rotate(360deg); } } @keyframes  pace-spinner { 0% { transform: rotate(0deg); transform: rotate(0deg); } 100% { transform: rotate(360deg); transform: rotate(360deg); } }
</style>

<script>
    window.paceOptions = {
        ajax: false, // disabled
        document: false, // disabled
        eventLag: false, // disabled
    };
</script>
<script src="/assets/default/vendors/pace-loading/pace.min.js"></script>
    </head>

<body class="">

<div id="app" class="">
    
            <div class="top-navbar d-flex border-bottom">
    <div class="container d-flex justify-content-between flex-column flex-lg-row">
        <div class="top-contact-box border-bottom d-flex flex-column flex-md-row align-items-center justify-content-center">

            
            <div class="d-flex align-items-center justify-content-between justify-content-md-center">

                
                

                                    <form action="/locale" method="post" class="mr-15 mx-md-20">
                        <input type="hidden" name="_token" value="aXa5IfOq9rYhvVexK4jw0FfbM2rVWEZEvxBH6z18">

                        <input type="hidden" name="locale">

                        <div class="language-select">
                            <div id="localItems"
                                 data-selected-country="US"
                                 data-countries='{&quot;IQ&quot;:&quot;Arabic&quot;,&quot;US&quot;:&quot;English&quot;,&quot;ES&quot;:&quot;Spanish&quot;}'
                            ></div>
                        </div>
                    </form>
                

                <form action="/search" method="get" class="form-inline my-2 my-lg-0 navbar-search position-relative">
                    <input class="form-control mr-5 rounded" type="text" name="search" placeholder="Search..." aria-label="Search">

                    <button type="submit" class="btn-transparent d-flex align-items-center justify-content-center search-icon">
                        <i data-feather="search" width="20" height="20" class="mr-10"></i>
                    </button>
                </form>
            </div>
        </div>

        <div class="xs-w-100 d-flex align-items-center justify-content-between ">
            <div class="d-flex">

                <div class="dropdown">
    <button type="button" disabled class="btn btn-transparent dropdown-toggle" id="navbarShopingCart" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
        <i data-feather="shopping-cart" width="20" height="20" class="mr-10"></i>

            </button>

    <div class="dropdown-menu" aria-labelledby="navbarShopingCart">
        <div class="d-md-none border-bottom mb-20 pb-10 text-right">
            <i class="close-dropdown" data-feather="x" width="32" height="32" class="mr-10"></i>
        </div>
        <div class="h-100">
            <div class="navbar-shopping-cart h-100" data-simplebar>
                                    <div class="d-flex align-items-center text-center py-50">
                        <i data-feather="shopping-cart" width="20" height="20" class="mr-10"></i>
                        <span class="">Your cart is empty</span>
                    </div>
                            </div>
        </div>
    </div>
</div>

                <div class="border-left mx-5 mx-lg-15"></div>

                <div class="dropdown">
    <button type="button" class="btn btn-transparent dropdown-toggle" disabled id="navbarNotification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i data-feather="bell" width="20" height="20" class="mr-10"></i>

            </button>

    <div class="dropdown-menu pt-20" aria-labelledby="navbarNotification">
        <div class="d-flex flex-column h-100">
            <div class="mb-auto navbar-notification-card" data-simplebar>
                <div class="d-md-none border-bottom mb-20 pb-10 text-right">
                    <i class="close-dropdown" data-feather="x" width="32" height="32" class="mr-10"></i>
                </div>

                                    <div class="d-flex align-items-center text-center py-50">
                        <i data-feather="bell" width="20" height="20" class="mr-10"></i>
                        <span class="">Empty notifications</span>
                    </div>
                
            </div>

                    </div>
    </div>
</div>
            </div>

            
            <div class="d-flex align-items-center ml-md-50">
        <a href="/login" class="py-5 px-10 mr-10 text-dark-blue font-14">Login</a>
        <a href="/register" class="py-5 px-10 text-dark-blue font-14">Register</a>
    </div>
        </div>
    </div>
</div>


        <div id="navbarVacuum"></div>
<nav id="navbar" class="navbar navbar-expand-lg navbar-light">
    <div class="container">
        <div class="d-flex align-items-center justify-content-between w-100">

            <a class="navbar-brand navbar-order d-flex align-items-center justify-content-center mr-0 " href="/">
                                    <img src="/store/1/default_images/logo2.png" class="img-cover" alt="site logo">
                            </a>

            <button class="navbar-toggler navbar-order" type="button" id="navbarToggle">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="mx-lg-30 d-none d-lg-flex flex-grow-1 navbar-toggle-content " id="navbarContent">
                <div class="navbar-toggle-header text-right d-lg-none">
                    <button class="btn-transparent" id="navbarClose">
                        <i data-feather="x" width="32" height="32"></i>
                    </button>
                </div>

                <ul class="navbar-nav mr-auto d-flex align-items-center">
                                            <li class="mr-lg-25">
                            <div class="menu-category">
                                <ul>
                                    <li class="cursor-pointer user-select-none d-flex xs-categories-toggle">
                                        <i data-feather="grid" width="20" height="20" class="mr-10 d-none d-lg-block"></i>
                                        Categories

                                        <ul class="cat-dropdown-menu">
                                                                                            <li>
                                                    <a href="/categories/Development">
                                                        <div class="d-flex align-items-center">
                                                            <img src="/store/1/default_images/categories_icons/code.png" class="cat-dropdown-menu-icon mr-10" alt="ComputerScience icon">
                                                            ComputerScience
                                                        </div>

                                                                                                                    <i data-feather="chevron-right" width="20" height="20" class="d-none d-lg-inline-block ml-10"></i>
                                                            <i data-feather="chevron-down" width="20" height="20" class="d-inline-block d-lg-none"></i>
                                                                                                            </a>

                                                                                                            <ul class="sub-menu" data-simplebar >
                                                                                                                            <li>
                                                                    <a href="/categories/Development/MachineLearning">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/layout.png" class="cat-dropdown-menu-icon mr-10" alt="Artificial intelligence icon">
                                                                        
                                                                        Artificial intelligence
                                                                    </a>
                                                                </li>
                                                                                                                            <li>
                                                                    <a href="/categories/Development/Mobile-Development">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/smartphone.png" class="cat-dropdown-menu-icon mr-10" alt="Mobile Development icon">
                                                                        
                                                                        Mobile Development
                                                                    </a>
                                                                </li>
                                                                                                                            <li>
                                                                    <a href="/categories/Development/Game-Development">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/codesandbox.png" class="cat-dropdown-menu-icon mr-10" alt="Game Development icon">
                                                                        
                                                                        Game Development
                                                                    </a>
                                                                </li>
                                                                                                                    </ul>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="/categories/Business">
                                                        <div class="d-flex align-items-center">
                                                            <img src="/store/1/default_images/categories_icons/anchor.png" class="cat-dropdown-menu-icon mr-10" alt="Business icon">
                                                            Business
                                                        </div>

                                                                                                                    <i data-feather="chevron-right" width="20" height="20" class="d-none d-lg-inline-block ml-10"></i>
                                                            <i data-feather="chevron-down" width="20" height="20" class="d-inline-block d-lg-none"></i>
                                                                                                            </a>

                                                                                                            <ul class="sub-menu" data-simplebar >
                                                                                                                            <li>
                                                                    <a href="/categories/Business/Management">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/users.png" class="cat-dropdown-menu-icon mr-10" alt="Management icon">
                                                                        
                                                                        Management
                                                                    </a>
                                                                </li>
                                                                                                                            <li>
                                                                    <a href="/categories/Business/Communications">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/share-2.png" class="cat-dropdown-menu-icon mr-10" alt="Communications icon">
                                                                        
                                                                        Communications
                                                                    </a>
                                                                </li>
                                                                                                                            <li>
                                                                    <a href="/categories/Business/Business-Strategy">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/target.png" class="cat-dropdown-menu-icon mr-10" alt="Business Strategy icon">
                                                                        
                                                                        Business Strategy
                                                                    </a>
                                                                </li>
                                                                                                                    </ul>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="/categories/Marketing">
                                                        <div class="d-flex align-items-center">
                                                            <img src="/store/1/default_images/categories_icons/pie-chart.png" class="cat-dropdown-menu-icon mr-10" alt="Marketing icon">
                                                            Marketing
                                                        </div>

                                                                                                            </a>

                                                                                                    </li>
                                                                                            <li>
                                                    <a href="/categories/Lifestyle">
                                                        <div class="d-flex align-items-center">
                                                            <img src="/store/1/default_images/categories_icons/umbrella.png" class="cat-dropdown-menu-icon mr-10" alt="Lifestyle icon">
                                                            Lifestyle
                                                        </div>

                                                                                                                    <i data-feather="chevron-right" width="20" height="20" class="d-none d-lg-inline-block ml-10"></i>
                                                            <i data-feather="chevron-down" width="20" height="20" class="d-inline-block d-lg-none"></i>
                                                                                                            </a>

                                                                                                            <ul class="sub-menu" data-simplebar >
                                                                                                                            <li>
                                                                    <a href="/categories/Lifestyle/Lifestyle">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/sun.png" class="cat-dropdown-menu-icon mr-10" alt="Lifestyle icon">
                                                                        
                                                                        Lifestyle
                                                                    </a>
                                                                </li>
                                                                                                                            <li>
                                                                    <a href="/categories/Lifestyle/Beauty-and-Makeup">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/droplet.png" class="cat-dropdown-menu-icon mr-10" alt="Beauty &amp; Makeup icon">
                                                                        
                                                                        Beauty &amp; Makeup
                                                                    </a>
                                                                </li>
                                                                                                                    </ul>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="/categories/Health-and-Fitness">
                                                        <div class="d-flex align-items-center">
                                                            <img src="/store/1/default_images/categories_icons/heart.png" class="cat-dropdown-menu-icon mr-10" alt="Health &amp; Fitness icon">
                                                            Health &amp; Fitness
                                                        </div>

                                                                                                            </a>

                                                                                                    </li>
                                                                                            <li>
                                                    <a href="/categories/Academics">
                                                        <div class="d-flex align-items-center">
                                                            <img src="/store/1/default_images/categories_icons/briefcase.png" class="cat-dropdown-menu-icon mr-10" alt="Academics icon">
                                                            Academics
                                                        </div>

                                                                                                                    <i data-feather="chevron-right" width="20" height="20" class="d-none d-lg-inline-block ml-10"></i>
                                                            <i data-feather="chevron-down" width="20" height="20" class="d-inline-block d-lg-none"></i>
                                                                                                            </a>

                                                                                                            <ul class="sub-menu" data-simplebar >
                                                                                                                            <li>
                                                                    <a href="/categories/Academics/Math">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/divide-square.png" class="cat-dropdown-menu-icon mr-10" alt="Math icon">
                                                                        
                                                                        Math
                                                                    </a>
                                                                </li>
                                                                                                                            <li>
                                                                    <a href="/categories/Academics/Science">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/zap.png" class="cat-dropdown-menu-icon mr-10" alt="Science icon">
                                                                        
                                                                        Science
                                                                    </a>
                                                                </li>
                                                                                                                            <li>
                                                                    <a href="/categories/Academics/Language">
                                                                                                                                                    <img src="/store/1/default_images/categories_icons/sub_categories/globe.png" class="cat-dropdown-menu-icon mr-10" alt="Language icon">
                                                                        
                                                                        Language
                                                                    </a>
                                                                </li>
                                                                                                                    </ul>
                                                                                                    </li>
                                                                                            <li>
                                                    <a href="/categories/Design">
                                                        <div class="d-flex align-items-center">
                                                            <img src="/store/1/default_images/categories_icons/feather.png" class="cat-dropdown-menu-icon mr-10" alt="Design icon">
                                                            Design
                                                        </div>

                                                                                                            </a>

                                                                                                    </li>
                                                                                    </ul>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    
                                                                        <li class="nav-item">
                                <a class="nav-link" href="/">Home</a>
                            </li>
                                                    <li class="nav-item">
                                <a class="nav-link" href="/classes?sort=newest">Internship Courses</a>
                            </li>
                                                    <li class="nav-item">
                                <a class="nav-link" href="/instructor-finder">Instructors</a>
                            </li>
                                                    <li class="nav-item">
                                <a class="nav-link" href="/products">Projects Store</a>
                            </li>
                                                    <li class="nav-item">
                                <a class="nav-link" href="/forums">Forums</a>
                            </li>
                                                            </ul>
            </div>

            <div class="nav-icons-or-start-live navbar-order">

                                    <a href="/login" class="d-none d-lg-flex btn btn-sm btn-primary nav-start-a-live-btn">
                        Start learning
                    </a>

                    <a href="/login" class="d-flex d-lg-none text-primary nav-start-a-live-btn font-14">
                        Start learning
                    </a>
                
                <div class="d-none nav-notify-cart-dropdown top-navbar ">
                    <div class="dropdown">
    <button type="button" disabled class="btn btn-transparent dropdown-toggle" id="navbarShopingCart" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
        <i data-feather="shopping-cart" width="20" height="20" class="mr-10"></i>

            </button>

    <div class="dropdown-menu" aria-labelledby="navbarShopingCart">
        <div class="d-md-none border-bottom mb-20 pb-10 text-right">
            <i class="close-dropdown" data-feather="x" width="32" height="32" class="mr-10"></i>
        </div>
        <div class="h-100">
            <div class="navbar-shopping-cart h-100" data-simplebar>
                                    <div class="d-flex align-items-center text-center py-50">
                        <i data-feather="shopping-cart" width="20" height="20" class="mr-10"></i>
                        <span class="">Your cart is empty</span>
                    </div>
                            </div>
        </div>
    </div>
</div>

                    <div class="border-left mx-15"></div>

                    <div class="dropdown">
    <button type="button" class="btn btn-transparent dropdown-toggle" disabled id="navbarNotification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i data-feather="bell" width="20" height="20" class="mr-10"></i>

            </button>

    <div class="dropdown-menu pt-20" aria-labelledby="navbarNotification">
        <div class="d-flex flex-column h-100">
            <div class="mb-auto navbar-notification-card" data-simplebar>
                <div class="d-md-none border-bottom mb-20 pb-10 text-right">
                    <i class="close-dropdown" data-feather="x" width="32" height="32" class="mr-10"></i>
                </div>

                                    <div class="d-flex align-items-center text-center py-50">
                        <i data-feather="bell" width="20" height="20" class="mr-10"></i>
                        <span class="">Empty notifications</span>
                    </div>
                
            </div>

                    </div>
    </div>
</div>
                </div>

            </div>
        </div>
    </div>
</nav>

    
    
        
    <section class="my-50 container text-center">
        <div class="row justify-content-md-center">
            <div class="col col-md-6">
                <img src="/store/1/default_images/404.svg" class="img-cover " alt="">
            </div>
        </div>

        <h2 class="mt-25 font-36">Page not found!</h2>
        <p class="mt-25 font-16">Sorry, this page is not available...</p>
    </section>

            <footer class="footer bg-secondary position-relative user-select-none">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class=" footer-subscribe d-block d-md-flex align-items-center justify-content-between">
                    <div class="flex-grow-1">
                        <strong>Join us today</strong>
                        <span class="d-block mt-5 text-white">#We will send the best deals and offers to your email.</span>
                    </div>
                    <div class="subscribe-input bg-white p-10 flex-grow-1 mt-30 mt-md-0">
                        <form action="/newsletters" method="post">
                            <input type="hidden" name="_token" value="aXa5IfOq9rYhvVexK4jw0FfbM2rVWEZEvxBH6z18">

                            <div class="form-group d-flex align-items-center m-0">
                                <div class="w-100">
                                    <input type="text" name="newsletter_email" class="form-control border-0 " placeholder="Enter your email here"/>
                                                                    </div>
                                <button type="submit" class="btn btn-primary rounded-pill">Join</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="container">
        <div class="row">

                            <div class="col-6 col-md-3">
                                                                        <span class="header d-block text-white font-weight-bold">About US</span>
                        
                                                    <div class="mt-20">
                                <p><font color="#ffffff">Edygrad is a fully-featured learning management system that helps you to run your education business in several hours. This platform helps instructors to create professional education materials and helps students to learn from the best instructors.Edygrad<span style="orphans: 2; text-align: left; text-indent: 0px; widows: 2; text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; float: none; display: inline !important;">&nbsp;is a fully-featured learning management system that helps you to run your education business in several hours. This platform helps instructors to create professional education materials and helps students to learn from the best instructors.</span></font></p>
                            </div>
                                                            </div>
                            <div class="col-6 col-md-3">
                                                                        <span class="header d-block text-white font-weight-bold">Additional Links</span>
                        
                                                    <div class="mt-20">
                                <p><a href="/login"><font color="#ffffff">- Login</font></a></p><p><font color="#ffffff"><a href="/register"><font color="#ffffff">- Register</font></a><br></font></p><p><a href="/blog"><font color="#ffffff">- Blog</font></a></p><p><a href="/contact"><font color="#ffffff">- Contact us</font></a></p><p><font color="#ffffff"><a href="/certificate_validation"><font color="#ffffff">- Certificate validation</font></a><br></font></p><p><font color="#ffffff"><a href="/become-instructor"><font color="#ffffff">- Become instructor</font></a><br></font></p><p><a href="/pages/terms"><font color="#ffffff">- Terms &amp; rules</font></a></p><p><a href="/pages/about"><font color="#ffffff">- About us</font></a><br></p>
                            </div>
                                                            </div>
                            <div class="col-6 col-md-3">
                                                                        <span class="header d-block text-white font-weight-bold">Similar Businesses</span>
                        
                                                    <div class="mt-20">
                                <p><a href="https://www.udemy.com/" target="_blank"><font color="#ffffff">- Udemy</font></a></p><p><a href="https://www.skillshare.com/" target="_blank"><font color="#ffffff">- Skillshare</font></a></p><p><a href="https://www.coursera.org/" target="_blank"><font color="#ffffff">- Coursera</font></a></p><p><a href="https://www.linkedin.com/learning/" target="_blank"><font color="#ffffff">- Lynda</font></a></p><p><a href="https://www.skillsoft.com/" target="_blank"><font color="#ffffff">- Skillsoft</font></a></p><p><a href="https://www.udacity.com/" target="_blank"><font color="#ffffff">- Udacity</font></a></p><p><a href="https://www.edx.org/" target="_blank"><font color="#ffffff">- edX</font></a></p><p><a href="https://www.masterclass.com/" target="_blank"><font color="#ffffff">- Masterclass</font></a><br></p>
                            </div>
                                                            </div>
                            <div class="col-6 col-md-3">
                                                                        <span class="header d-block text-white font-weight-bold">Edygrad</span>
                        
                                                    <div class="mt-20">
                                <p><a title="Notnt" href="https://codecanyon.net"></a></p>
                            </div>
                                                            </div>
            
        </div>

        <div class="mt-40 border-blue py-25 d-flex align-items-center justify-content-between">
            <div class="footer-logo">
                <a href="/">
                                            <img src="/store/1/default_images/logo2.png" class="img-cover" alt="footer logo">
                                    </a>
            </div>
            <div class="footer-social">
                                                            <a href="https://www.instagram.com/">
                            <img src="/store/1/default_images/social/instagram.svg" alt="Instagram" class="mr-15">
                        </a>
                                            <a href="https://web.whatsapp.com/">
                            <img src="/store/1/default_images/social/whatsapp.svg" alt="Whatsapp" class="mr-15">
                        </a>
                                            <a href="https://twitter.com/">
                            <img src="/store/1/default_images/social/twitter.svg" alt="Twitter" class="mr-15">
                        </a>
                                            <a href="https://www.facebook.com/">
                            <img src="/store/1/default_images/social/facebook.svg" alt="Facebook" class="mr-15">
                        </a>
                                                </div>
        </div>
    </div>

            <div class="footer-copyright-card">
            <div class="container d-flex align-items-center justify-content-between py-15">
                <div class="font-14 text-white">All rights are reserved for learning management system platform</div>

                <div class="d-flex align-items-center justify-content-center">
                                            <div class="d-flex align-items-center text-white font-14">
                            <i data-feather="phone" width="20" height="20" class="mr-10"></i>
                            9505367011
                        </div>
                    
                                            <div class="border-left mx-5 mx-lg-15 h-100"></div>

                        <div class="d-flex align-items-center text-white font-14">
                            <i data-feather="mail" width="20" height="20" class="mr-10"></i>
                            join@edygrad.in
                        </div>
                                    </div>
            </div>
        </div>
    
</footer>
    
    
    </div>
<!-- Template JS File -->
<script src="/assets/default/js/app.js"></script>
<script src="/assets/default/vendors/feather-icons/dist/feather.min.js"></script>
<script src="/assets/default/vendors/moment.min.js"></script>
<script src="/assets/default/vendors/sweetalert2/dist/sweetalert2.min.js"></script>
<script src="/assets/default/vendors/toast/jquery.toast.min.js"></script>
<script type="text/javascript" src="/assets/default/vendors/simplebar/simplebar.min.js"></script>

    <div class="cookie-security-dialog p-20 bg-gray rounded-lg">
        <h3 class="font-14 font-weight-bold text-white">Your privacy matters</h3>
        <p class="mt-5 text-white font-12">Cookies and similar technologies are used on our sites to personalize content and ads. You can find further details and change your personal settings below. By clicking OK, or by clicking any content on our sites, you agree to the use of these cookies and similar technologies.</p>

        <div class="mt-10 d-flex flex-wrap align-items-center">
            <button type="button" class="js-accept-all-cookies btn btn-primary btn-sm flex-grow-1 mr-0 mr-md-5">Accept all cookies</button>
            <button type="button" class="js-cookie-customize-settings btn btn-light btn-sm flex-grow-1 mt-10 mt-md-0">Customize settings</button>
        </div>
    </div>

    <div id="cookieSecurityModal" class="d-none">
        <h3 class="section-title after-line font-20 text-dark-blue mb-10">GDPR</h3>

        <p class="mt-10 cookie-security-modal-description"><p>When you visit any of our websites, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device and is mostly used to make the site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized web experience. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to find out more and manage your preferences. Please note, that blocking some types of cookies may impact your experience of the site and the services we are able to offer.</p></p>

                    <form class="js-cookie-form-customize-inputs mt-25">

                                    
                    <div class="cookie-settings-modal-items-card mb-15">
                        <div class="form-group d-flex align-items-center mb-0">
                            <div class="custom-control custom-checkbox c-not-allowed">
                                <input type="checkbox" name="settings" value="strictly_necessary" class="custom-control-input"  checked=&quot;checked&quot; disabled=&quot;disabled&quot;  id="cookieModalItemdDRjfkGvQfFzQJpa_record">
                                <label class="custom-control-label" for="cookieModalItemdDRjfkGvQfFzQJpa_record"></label>
                            </div>
                            <label class="cursor-pointer font-14 text-gray mb-0 c-not-allowed" for="cookieModalItemdDRjfkGvQfFzQJpa_record">Strictly Necessary</label>

                                                            <input type="hidden" name="settings" value="strictly_necessary">
                            
                                                            <button type="button" class="js-cookie-settings-modal-items-help btn-transparent ml-15">
                                    <i data-feather="help-circle" width="20" height="20" class="text-gray"></i>
                                </button>
                                                    </div>

                        <ul class="cookie-settings-modal-items-card__description">
                            <li class="font-12 text-gray">These cookies are necessary for our website to function properly and cannot be switched off in our systems. They are usually only set in response to actions made by you that amount to a request for services, such as setting your privacy preferences, logging in or filling in forms, or where they’re essential to providing you with a service you have requested. You cannot opt out of these cookies. You can set your browser to block or alert you about these cookies, but if you do, some parts of the site will not then work. These cookies do not store any personally identifiable information.</li>
                        </ul>
                    </div>

                                    
                    <div class="cookie-settings-modal-items-card mb-15">
                        <div class="form-group d-flex align-items-center mb-0">
                            <div class="custom-control custom-checkbox ">
                                <input type="checkbox" name="settings" value="performance_cookies" class="custom-control-input"  id="cookieModalItemmOzJowgvTnWFlRzz_record">
                                <label class="custom-control-label" for="cookieModalItemmOzJowgvTnWFlRzz_record"></label>
                            </div>
                            <label class="cursor-pointer font-14 text-gray mb-0 " for="cookieModalItemmOzJowgvTnWFlRzz_record">Performance Cookies</label>

                            
                                                            <button type="button" class="js-cookie-settings-modal-items-help btn-transparent ml-15">
                                    <i data-feather="help-circle" width="20" height="20" class="text-gray"></i>
                                </button>
                                                    </div>

                        <ul class="cookie-settings-modal-items-card__description">
                            <li class="font-12 text-gray">These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site, which helps us optimize your experience. All information these cookies collect is aggregated and therefore anonymous. If you do not allow these cookies we will not be able to use your data in this way.</li>
                        </ul>
                    </div>

                                    
                    <div class="cookie-settings-modal-items-card mb-15">
                        <div class="form-group d-flex align-items-center mb-0">
                            <div class="custom-control custom-checkbox ">
                                <input type="checkbox" name="settings" value="functional_cookies" class="custom-control-input"  id="cookieModalItemXBMtdYaeSrqMicTH_record">
                                <label class="custom-control-label" for="cookieModalItemXBMtdYaeSrqMicTH_record"></label>
                            </div>
                            <label class="cursor-pointer font-14 text-gray mb-0 " for="cookieModalItemXBMtdYaeSrqMicTH_record">Functional Cookies</label>

                            
                                                            <button type="button" class="js-cookie-settings-modal-items-help btn-transparent ml-15">
                                    <i data-feather="help-circle" width="20" height="20" class="text-gray"></i>
                                </button>
                                                    </div>

                        <ul class="cookie-settings-modal-items-card__description">
                            <li class="font-12 text-gray">These cookies enable the website to provide enhanced functionality and personalization. They may be set by us or by third-party providers whose services we have added to our pages. If you do not allow these cookies then some or all of these services may not function properly.</li>
                        </ul>
                    </div>

                                    
                    <div class="cookie-settings-modal-items-card mb-15">
                        <div class="form-group d-flex align-items-center mb-0">
                            <div class="custom-control custom-checkbox ">
                                <input type="checkbox" name="settings" value="targeting_cookies" class="custom-control-input"  id="cookieModalItemXlLqzsvNpRqdcNWP_record">
                                <label class="custom-control-label" for="cookieModalItemXlLqzsvNpRqdcNWP_record"></label>
                            </div>
                            <label class="cursor-pointer font-14 text-gray mb-0 " for="cookieModalItemXlLqzsvNpRqdcNWP_record">Targeting Cookies</label>

                            
                                                            <button type="button" class="js-cookie-settings-modal-items-help btn-transparent ml-15">
                                    <i data-feather="help-circle" width="20" height="20" class="text-gray"></i>
                                </button>
                                                    </div>

                        <ul class="cookie-settings-modal-items-card__description">
                            <li class="font-12 text-gray">These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites. They do not store directly personal information but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.</li>
                        </ul>
                    </div>

                
            </form>
        
        <div class="d-flex flex-wrap align-items-center mt-20 pt-15 border-top">
            <button type="button" class="js-store-customize-cookies d-inline-flex d-md-none btn btn-primary btn-sm">Confirm</button>
            <button type="button" class="js-store-customize-cookies d-none d-md-inline-flex btn btn-primary btn-sm">Confirm my choices</button>

            <button type="button" class="js-accept-all-cookies d-inline-flex d-md-none btn btn-outline-primary btn-sm mx-15">Accept all</button>
            <button type="button" class="js-accept-all-cookies d-none d-md-inline-flex btn btn-outline-primary btn-sm mx-15">Accept all cookies</button>

            <button type="button" class="btn-transparent close-swl ml-auto font-14 text-danger">Cancel</button>
        </div>
    </div>

    <script>
        var oopsLang = 'Oops...';
        var somethingWentWrongLang = 'Something went wrong...';
    </script>
    <script type="text/javascript" src="/assets/default/js/parts/cookie-security.min.js"></script>


<script>
    var deleteAlertTitle = 'Are you sure?';
    var deleteAlertHint = 'This action cannot be undone!';
    var deleteAlertConfirm = 'Delete';
    var deleteAlertCancel = 'Cancel';
    var deleteAlertSuccess = 'Success';
    var deleteAlertFail = 'Failed';
    var deleteAlertFailHint = 'Error while deleting item!';
    var deleteAlertSuccessHint = 'Item successfully deleted.';
    var forbiddenRequestToastTitleLang = '&quot;FORBIDDEN&quot; Request';
    var forbiddenRequestToastMsgLang = 'You not access to this content.';
</script>


    <link href="/assets/default/vendors/flagstrap/css/flags.css" rel="stylesheet">
    <script src="/assets/default/vendors/flagstrap/js/jquery.flagstrap.min.js"></script>
    <script src="/assets/default/js/parts/top_nav_flags.min.js"></script>
    <script src="/assets/default/js/parts/navbar.min.js"></script>

<script src="/assets/default/js/parts/main.min.js"></script>

<script>
    
    
</script>
</body>
</html>
